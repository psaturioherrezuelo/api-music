package controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vista.Login;

public class ControllerWindows extends Login {

//	Login vent = new Login();
//	private boolean cnd;
//	
//	public ControllerWindows() {
//		
//		btniniciar.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				
//				if (e.getSource() == registrar) {
//					
////					p.register(txtUser.getText(), txtPassword.getText());
//					
//				} else if (e.getSource() == btniniciar) {
//					
////					boolean cnd = p.login(txtUser.getText(),txtPassword.getText());
//					
//					cnd = false;
//					
//					if(cnd==true) {
//						System.out.println("bien");
//					}else {
//						System.out.println("mal");
//					}
//					
//				} else if (e.getSource() == salir) {
//					
//					System.exit(0);
//					
//				} 
//				
//				System.out.println(e.getActionCommand());
//				
//			}
//		});
//		
//	}
//	
//	public boolean isCnd() {
//		return cnd;
//	}
//
//	public void setCnd(boolean cnd) {
//		this.cnd = cnd;
//	}
//	
//	public String us() {
//		
//		String us = txtUser.getText();
//		
//		return us;
//		
//	}

	
}
